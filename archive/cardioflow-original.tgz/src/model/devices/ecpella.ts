/**
 * ECpella = VA-ECMO + trans-aortic axial pump, running simultaneously.
 *
 * There is deliberately no separate physiology here. ECpella is the superposition
 * of the two device couplings already defined: the ECMO circuit moves volume from
 * the venous reservoir to the arterial tree, and the axial pump moves volume from
 * the LV cavity to the ascending aorta. Keeping it as a pure composition is what
 * guarantees the comparison "ECMO alone vs ECMO + unloading" is an honest one —
 * the only thing that changes between those two states is the LV-to-aorta path.
 */

import type { DeviceKind } from '../cardiovascular/types';

export interface ActiveDevices {
  iabp: boolean;
  impella: boolean;
  ecmo: boolean;
}

export function activeDevices(kind: DeviceKind): ActiveDevices {
  return {
    iabp: kind === 'iabp',
    impella: kind === 'impella' || kind === 'ecpella',
    ecmo: kind === 'vaEcmo' || kind === 'ecpella',
  };
}

export const DEVICE_LABELS: Record<DeviceKind, string> = {
  none: 'No support',
  iabp: 'IABP',
  impella: 'Impella',
  vaEcmo: 'VA-ECMO',
  ecpella: 'ECpella',
};

export const DEVICE_SHORT: Record<DeviceKind, string> = {
  none: 'NONE',
  iabp: 'IABP',
  impella: 'IMPELLA',
  vaEcmo: 'VA-ECMO',
  ecpella: 'ECPELLA',
};

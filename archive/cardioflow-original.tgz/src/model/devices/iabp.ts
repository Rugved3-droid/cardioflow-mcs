/**
 * Intra-aortic balloon pump.
 *
 * The balloon is modelled as a volume displacement in the descending thoracic
 * aorta (the `sa` compartment). Inflating the balloon by dV displaces dV of blood
 * out of that compartment; deflating it creates an equal void that draws blood in.
 * We therefore inject `-dVballoon/dt` as a flow term on the sa compartment. Nothing
 * else about the IABP is special-cased: diastolic augmentation, afterload reduction,
 * and the harm done by mistimed inflation all fall out of that single coupling.
 *
 * The balloon volume waveform is analytic in cardiac phase, so its derivative is
 * exact and the volume returns to zero every beat (no integration drift).
 *
 * CALIBRATION NOTE: real balloon volume displacement is not a pure volume source —
 * it is limited by aortic compliance, balloon/aorta diameter ratio and helium
 * transit time. See docs/MODEL.md, "Parameters requiring external calibration".
 */

import type { IabpTimingMode } from '../cardiovascular/types';
import { clamp } from '../cardiovascular/elastance';

/** Timing offsets as a fraction of the cardiac cycle. */
interface TimingOffsets {
  /** shift of inflation onset relative to aortic valve closure */
  inflate: number;
  /** shift of deflation onset relative to end-diastole */
  deflate: number;
  label: string;
}

export const IABP_TIMING: Record<IabpTimingMode, TimingOffsets> = {
  optimal: { inflate: 0.0, deflate: 0.0, label: 'Optimal (inflate at dicrotic notch)' },
  earlyInflation: { inflate: -0.13, deflate: 0.0, label: 'Early inflation (before AV closure)' },
  lateInflation: { inflate: +0.14, deflate: 0.0, label: 'Late inflation (after dicrotic notch)' },
  earlyDeflation: { inflate: 0.0, deflate: -0.22, label: 'Early deflation (mid-diastole)' },
  lateDeflation: { inflate: 0.0, deflate: +0.12, label: 'Late deflation (into systole)' },
};

/** Inflation ramp duration, fraction of cycle. */
const INFLATE_DURATION = 0.07;
/** Deflation ramp duration, fraction of cycle — deliberately faster than inflation. */
const DEFLATE_DURATION = 0.05;
/** How far before end-diastole optimal deflation begins, fraction of cycle. */
const DEFLATE_LEAD = 0.07;
/** Fallback aortic valve closure phase when the valve is not opening at all. */
export const DEFAULT_AV_CLOSURE_PHASE = 0.33;

function smoothstep(x: number): number {
  const t = clamp(x, 0, 1);
  return t * t * (3 - 2 * t);
}
function smoothstepDeriv(x: number): number {
  if (x <= 0 || x >= 1) return 0;
  return 6 * x * (1 - x);
}

export interface BalloonWindow {
  inflateStart: number;
  deflateStart: number;
  inflateEnd: number;
  deflateEnd: number;
}

export function balloonWindow(
  timing: IabpTimingMode,
  avClosurePhase: number,
): BalloonWindow {
  const off = IABP_TIMING[timing];
  const inflateStart = clamp(avClosurePhase + off.inflate, 0.05, 0.92);
  const deflateStart = clamp(1 - DEFLATE_LEAD + off.deflate, inflateStart + 0.08, 1.14);
  return {
    inflateStart,
    deflateStart,
    inflateEnd: inflateStart + INFLATE_DURATION,
    deflateEnd: deflateStart + DEFLATE_DURATION,
  };
}

/** Single-beat balloon pulse on an unwrapped phase axis. Returns [volumeFraction, d/dphase]. */
function pulse(u: number, w: BalloonWindow): [number, number] {
  const a = (u - w.inflateStart) / INFLATE_DURATION;
  const b = (u - w.deflateStart) / DEFLATE_DURATION;
  if (a <= 0 || b >= 1) return [0, 0];
  const rise = smoothstep(a);
  const fall = smoothstep(b);
  const v = rise * (1 - fall);
  const dv =
    (smoothstepDeriv(a) / INFLATE_DURATION) * (1 - fall) -
    rise * (smoothstepDeriv(b) / DEFLATE_DURATION);
  return [v, dv];
}

export interface BalloonOutput {
  /** current balloon volume, mL */
  volume: number;
  /** dVolume/dt, mL/s — positive while inflating */
  dVdt: number;
  inflated: boolean;
}

/**
 * Balloon state at a point in the cardiac cycle.
 * `beat` drives the assist ratio (1:1, 1:2, 1:3).
 */
export function balloonState(
  phase: number,
  cycleTime: number,
  beat: number,
  maxVolume: number,
  timing: IabpTimingMode,
  avClosurePhase: number,
  assistRatio: 1 | 2 | 3,
  ramp: number,
): BalloonOutput {
  const w = balloonWindow(timing, avClosurePhase);
  let v = 0;
  let dv = 0;
  // Evaluate the current beat's pulse and the previous beat's tail (which can
  // spill past phase 1.0 with late deflation).
  for (const k of [0, 1]) {
    const beatIndex = beat - k;
    if (assistRatio > 1 && ((beatIndex % assistRatio) + assistRatio) % assistRatio !== 0) {
      continue;
    }
    const [pv, pdv] = pulse(phase + k, w);
    v += pv;
    dv += pdv;
  }
  const scale = maxVolume * ramp;
  return {
    volume: v * scale,
    dVdt: (dv * scale) / Math.max(cycleTime, 1e-3),
    inflated: v > 0.35,
  };
}

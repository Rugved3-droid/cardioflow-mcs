/**
 * Peripheral veno-arterial ECMO.
 *
 * Blood is drained from the systemic venous compartment and returned, retrograde,
 * into the descending aorta (the `sa` compartment). We hold circuit volume constant,
 * so drainage and return are equal at every instant.
 *
 * Two consequences fall out of that coupling and are the point of the whole module:
 *   1. draining the venous reservoir lowers right-heart transfer and therefore LV
 *      preload;
 *   2. returning that flow into the arterial tree raises systemic pressure, which
 *      is the LV's afterload.
 * Together they are how VA-ECMO can rescue systemic perfusion while worsening LV
 * loading. Nothing in this file implements that paradox directly — it emerges.
 *
 * CALIBRATION NOTE: real drainage is limited by cannula size, venous collapse and
 * pump preload sensitivity, and the arterial return meets a mixing/watershed zone
 * in the aorta that this single-compartment return does not represent.
 */

import { clamp } from '../cardiovascular/elastance';

/** Venous stressed volume below which drainage starts to chatter/limit. */
const DRAIN_FLOOR = 110; // mL stressed venous volume
const DRAIN_BAND = 160; // mL

export interface EcmoOutput {
  /** actual circuit flow, mL/s (drainage == return) */
  q: number;
  /** true when drainage is limiting the set flow (suction / chatter) */
  drainageLimited: boolean;
}

export const ECMO_PRESETS = [
  { label: 'Off', lpm: 0 },
  { label: 'Low', lpm: 2.0 },
  { label: 'Moderate', lpm: 3.5 },
  { label: 'High', lpm: 4.5 },
  { label: 'Full', lpm: 5.5 },
] as const;

export function lpmToMlS(lpm: number): number {
  return lpm / 0.06;
}
export function mlSToLpm(mlS: number): number {
  return mlS * 0.06;
}

export function ecmoFlow(targetFlow: number, vVen: number): EcmoOutput {
  if (targetFlow <= 0) return { q: 0, drainageLimited: false };
  const s = clamp((vVen - DRAIN_FLOOR) / DRAIN_BAND, 0, 1);
  const factor = s * s * (3 - 2 * s);
  const q = targetFlow * factor;
  return { q, drainageLimited: factor < 0.97 };
}

/**
 * Trans-aortic axial-flow pump (Impella-class).
 *
 * The pump sits across the aortic valve: inlet in the LV cavity, outlet in the
 * ascending aorta. Flow is a function of rotor speed (performance level) and the
 * head the pump works against, dP = P_aorta - P_LV.
 *
 *     Q(level, dP) = Qfree(level) * [ 1 - (dP / dPmax(level))^k ]
 *
 * During systole dP collapses toward zero (or reverses) and pump flow surges;
 * during diastole the pump works against the full aortic diastolic head and flow
 * falls. That produces the characteristic pulsatile motor-flow signal without any
 * special-casing, and it is why the device continues to unload the LV even when
 * the aortic valve never opens.
 *
 * CALIBRATION NOTE: Qfree and dPmax below are INTERNAL APPROXIMATIONS chosen to
 * span a clinically plausible range of support. They are NOT the manufacturer's
 * H-Q curves. `IMPELLA_CURVES` is the single place to substitute published or
 * bench-measured pump curves. See docs/MODEL.md.
 */

import type { ImpellaLevel } from '../cardiovascular/types';
import { clamp } from '../cardiovascular/elastance';

export interface PumpCurve {
  /** free-flow (zero head) flow, mL/s */
  qFree: number;
  /** shut-off head: pressure difference at which flow reaches zero, mmHg */
  dpMax: number;
  /** curve exponent; >1 keeps flow flat at low head and drops steeply near shut-off */
  exponent: number;
  /** nominal label shown in the UI */
  label: string;
}

export const IMPELLA_LEVELS: ImpellaLevel[] = ['P2', 'P4', 'P6', 'P8'];

export const IMPELLA_CURVES: Record<ImpellaLevel, PumpCurve> = {
  P2: { qFree: 26, dpMax: 72, exponent: 1.8, label: 'P2 — low support' },
  P4: { qFree: 42, dpMax: 88, exponent: 1.8, label: 'P4' },
  P6: { qFree: 56, dpMax: 104, exponent: 1.8, label: 'P6' },
  P8: { qFree: 70, dpMax: 120, exponent: 1.8, label: 'P8 — maximal support' },
};

/** LV volume below which the inlet starts to entrain the ventricular wall. */
const SUCTION_VOLUME = 14; // mL
const SUCTION_BAND = 20; // mL

export interface ImpellaOutput {
  /** flow LV -> ascending aorta, mL/s (never negative) */
  q: number;
  /** true when flow is being limited by low LV volume */
  suction: boolean;
}

/**
 * @param level      performance level
 * @param pAo        ascending aortic pressure, mmHg
 * @param pLv        LV pressure, mmHg
 * @param vLv        LV volume, mL (used for the suction limit)
 * @param ramp       0..1 speed ramp applied on switch-on / level change
 */
export function impellaFlow(
  level: ImpellaLevel,
  pAo: number,
  pLv: number,
  vLv: number,
  ramp: number,
): ImpellaOutput {
  if (ramp <= 0) return { q: 0, suction: false };
  const curve = IMPELLA_CURVES[level];
  const dp = pAo - pLv;

  let frac: number;
  if (dp <= 0) {
    // Head reversed (LV pressure exceeds aortic): the pump runs past free flow,
    // but not without limit — cap the overspeed contribution.
    frac = 1 + Math.min(-dp / curve.dpMax, 0.18);
  } else {
    frac = 1 - Math.pow(dp / curve.dpMax, curve.exponent);
  }
  let q = curve.qFree * ramp * clamp(frac, 0, 1.18);

  // Suction limit: as the LV empties the inlet cannot sustain flow.
  const s = clamp((vLv - SUCTION_VOLUME) / SUCTION_BAND, 0, 1);
  const suctionFactor = s * s * (3 - 2 * s);
  const suction = suctionFactor < 0.95 && q > 1;
  q *= suctionFactor;

  return { q: Math.max(q, 0), suction };
}

/** Linear blend between two adjacent pump curves. Used to ramp smoothly when the
 *  operator changes performance level, rather than stepping the flow. */
export function curveAtIndex(index: number): PumpCurve {
  const i = clamp(index, 0, IMPELLA_LEVELS.length - 1);
  const lo = Math.floor(i);
  const hi = Math.min(lo + 1, IMPELLA_LEVELS.length - 1);
  const f = i - lo;
  const a = IMPELLA_CURVES[IMPELLA_LEVELS[lo]];
  const b = IMPELLA_CURVES[IMPELLA_LEVELS[hi]];
  return {
    qFree: a.qFree + (b.qFree - a.qFree) * f,
    dpMax: a.dpMax + (b.dpMax - a.dpMax) * f,
    exponent: a.exponent,
    label: f < 0.5 ? a.label : b.label,
  };
}

/** Flow at a fractional performance level (see `curveAtIndex`). */
export function impellaFlowAtIndex(
  levelIndex: number,
  pAo: number,
  pLv: number,
  vLv: number,
  ramp: number,
): ImpellaOutput {
  if (ramp <= 0) return { q: 0, suction: false };
  const curve = curveAtIndex(levelIndex);
  const dp = pAo - pLv;

  let frac: number;
  if (dp <= 0) {
    frac = 1 + Math.min(-dp / curve.dpMax, 0.18);
  } else {
    frac = 1 - Math.pow(dp / curve.dpMax, curve.exponent);
  }
  let q = curve.qFree * ramp * clamp(frac, 0, 1.18);

  const s = clamp((vLv - SUCTION_VOLUME) / SUCTION_BAND, 0, 1);
  const suctionFactor = s * s * (3 - 2 * s);
  const suction = suctionFactor < 0.95 && q > 1;
  q *= suctionFactor;

  return { q: Math.max(q, 0), suction };
}

export function levelIndex(level: ImpellaLevel): number {
  return Math.max(IMPELLA_LEVELS.indexOf(level), 0);
}

/** Mean expected flow at a representative head — used for UI labelling only. */
export function nominalFlowLpm(level: ImpellaLevel): number {
  const curve = IMPELLA_CURVES[level];
  const q = curve.qFree * (1 - Math.pow(55 / curve.dpMax, curve.exponent));
  return Math.max(q, 0) * 0.06;
}

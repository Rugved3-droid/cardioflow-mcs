import type { CirculatoryParams, DeviceParams, DeviceKind } from '../cardiovascular/types';
import { BASELINE_PARAMS, DEFAULT_DEVICE } from '../cardiovascular/modelParameters';

export type PresetId =
  | 'normal'
  | 'hfref'
  | 'severeLvFailure'
  | 'cardiogenicShock'
  | 'highAfterloadShock';

export interface Preset {
  id: PresetId;
  name: string;
  short: string;
  summary: string;
  /** what the learner should expect to see; shown in the UI, not used by the model */
  expect: string[];
  params: CirculatoryParams;
  device?: Partial<DeviceParams>;
}

function withParams(over: Partial<CirculatoryParams>): CirculatoryParams {
  return { ...BASELINE_PARAMS, ...over };
}

export const PRESETS: Preset[] = [
  {
    id: 'normal',
    name: 'Normal circulation',
    short: 'Normal',
    summary:
      'Healthy left ventricle. Reference state for every comparison in the simulator.',
    expect: ['MAP ~90 mmHg', 'Cardiac output ~5 L/min', 'LVEDP < 12 mmHg', 'EF > 55%'],
    params: withParams({}),
  },
  {
    id: 'hfref',
    name: 'Heart failure, reduced EF',
    short: 'HFrEF',
    summary:
      'Chronically dilated, poorly contractile LV that is still compensated. Filling pressures are up; perfusion is maintained.',
    expect: [
      'Dilated LV, EF ~25-30%',
      'LVEDP elevated',
      'MAP still adequate',
      'PV loop shifted right, shorter',
    ],
    params: withParams({
      ees: 0.85,
      edpvrV0: 60,
      edpvrB: 0.0175,
      v0: 18,
      svr: 1.25,
      stressedVolume: 1020,
      heartRate: 82,
    }),
  },
  {
    id: 'severeLvFailure',
    name: 'Severe LV failure',
    short: 'Severe LV failure',
    summary:
      'Profound systolic dysfunction with congestion. Perfusion is marginal but not yet frankly shocked.',
    expect: [
      'EF ~15-20%',
      'LVEDP 20-25 mmHg',
      'Cardiac output 3-3.5 L/min',
      'Narrow pulse pressure',
    ],
    params: withParams({
      ees: 0.5,
      edpvrV0: 70,
      edpvrB: 0.018,
      v0: 20,
      svr: 1.35,
      stressedVolume: 1080,
      heartRate: 95,
    }),
  },
  {
    id: 'cardiogenicShock',
    name: 'Cardiogenic shock',
    short: 'Cardiogenic shock',
    summary:
      'The default teaching state. Severe systolic failure, hypotension, congestion and inadequate systemic flow.',
    expect: [
      'MAP ~50-60 mmHg',
      'Cardiac index low, CPO < 0.6 W',
      'LVEDP > 25 mmHg',
      'Dilated, barely ejecting LV',
    ],
    params: withParams({
      ees: 0.33,
      edpvrV0: 72,
      edpvrB: 0.019,
      v0: 22,
      svr: 1.15,
      stressedVolume: 1120,
      heartRate: 105,
      cSa: 1.2,
    }),
  },
  {
    id: 'highAfterloadShock',
    name: 'High-afterload cardiogenic shock',
    short: 'High-afterload shock',
    summary:
      'Shock with intense vasoconstriction — the phenotype in which afterload reduction matters most and in which VA-ECMO return pressure is most punishing.',
    expect: [
      'SVR markedly elevated',
      'Very low stroke volume',
      'LV distension prominent',
      'Afterload reduction produces large gains',
    ],
    params: withParams({
      ees: 0.36,
      edpvrV0: 70,
      edpvrB: 0.0205,
      v0: 22,
      svr: 2.0,
      stressedVolume: 1130,
      heartRate: 100,
      cSa: 0.95,
    }),
  },
];

export function getPreset(id: PresetId): Preset {
  return PRESETS.find((p) => p.id === id) ?? PRESETS[0];
}

export function deviceFor(kind: DeviceKind, over: Partial<DeviceParams> = {}): DeviceParams {
  return { ...DEFAULT_DEVICE, kind, ...over };
}

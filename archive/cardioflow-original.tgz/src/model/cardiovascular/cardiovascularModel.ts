/**
 * The simulation. One instance owns the entire cardiovascular state; everything
 * the UI draws is read back from here.
 *
 * Integration: Heun (explicit RK2) at a fixed DT = 0.1 ms. The stiffest time
 * constant in the model is R_aorticValve * C_ao ~ 3.4 ms, so DT sits ~34x inside
 * it and the scheme is comfortably stable without any artificial damping.
 */

import type {
  BeatMetrics,
  CirculatoryParams,
  CirculatoryState,
  DeviceParams,
  InstantaneousReadout,
} from './types';
import { evaluate, type Evaluation, type EvaluationContext } from './circulation';
import { instantaneousElastance } from './elastance';
import { BeatAccumulator, emptyMetrics } from './metrics';
import { DT, BASELINE_PARAMS, DEFAULT_DEVICE, PLAUSIBLE_BOUNDS } from './modelParameters';
import { activeDevices } from '../devices/ecpella';
import { levelIndex } from '../devices/impella';
import { DEFAULT_AV_CLOSURE_PHASE } from '../devices/iabp';

/** Points retained for one PV loop. */
export const PV_POINTS = 512;
/** PV loop sampling interval, s. */
const PV_SAMPLE_DT = 0.002;

/** Ramp time constants, s. */
const TAU_DEVICE = 0.55;
const TAU_IMPELLA = 0.8;
const TAU_ECMO = 1.1;
const TAU_LEVEL = 0.9;
const TAU_PRELOAD = 1.6;

const VALVE_HISTORY = 8;

function initialState(p: CirculatoryParams, d: DeviceParams): CirculatoryState {
  return {
    t: 0,
    phase: 0,
    beat: 0,
    vLv: 120,
    vAo: p.cAo * 80,
    vSa: p.cSa * 78,
    vVen: 420,
    vPu: p.cPu * 10,
    vBalloon: 0,
    deviceRamp: d.kind === 'iabp' ? 1 : 0,
    impellaRamp: activeDevices(d.kind).impella ? 1 : 0,
    impellaLevelSmooth: levelIndex(d.impellaLevel),
    ecmoRamp: activeDevices(d.kind).ecmo ? d.ecmoTargetFlow : 0,
    appliedStressedVolume: p.stressedVolume,
  };
}

export class CardiovascularModel {
  state: CirculatoryState;
  params: CirculatoryParams;
  device: DeviceParams;

  private acc = new BeatAccumulator();
  private lastEval: Evaluation;
  private metricsValue: BeatMetrics = emptyMetrics();
  private avClosurePhase = DEFAULT_AV_CLOSURE_PHASE;
  private valveHistory: number[] = [];
  private beatsSinceReset = 0;

  /** completed loop, interleaved as volume, pressure, volume, pressure ... */
  readonly pvLoop = new Float32Array(PV_POINTS * 2);
  pvLoopLength = 0;
  /** loop currently being traced */
  readonly pvPartial = new Float32Array(PV_POINTS * 2);
  pvPartialLength = 0;
  private pvSampleClock = 0;

  /** Raised when the state leaves the plausibility envelope (dev diagnostics). */
  instabilityWarning: string | null = null;

  constructor(
    params: CirculatoryParams = BASELINE_PARAMS,
    device: DeviceParams = DEFAULT_DEVICE,
  ) {
    this.params = { ...params };
    this.device = { ...device };
    this.state = initialState(this.params, this.device);
    this.lastEval = evaluate(this.state, this.params, this.device, this.context());
  }

  private context(): EvaluationContext {
    return {
      avClosurePhase: this.avClosurePhase,
      volumeSetpoint: this.state.appliedStressedVolume,
    };
  }

  get metrics(): BeatMetrics {
    return this.metricsValue;
  }

  setParams(next: Partial<CirculatoryParams>): void {
    this.params = { ...this.params, ...next };
  }

  setDevice(next: Partial<DeviceParams>): void {
    this.device = { ...this.device, ...next };
  }

  /** Hard reset to a new operating point. Used by presets and by the tests. */
  reset(params: CirculatoryParams, device: DeviceParams): void {
    this.params = { ...params };
    this.device = { ...device };
    this.state = initialState(this.params, this.device);
    this.acc.reset();
    this.metricsValue = emptyMetrics();
    this.avClosurePhase = DEFAULT_AV_CLOSURE_PHASE;
    this.valveHistory = [];
    this.beatsSinceReset = 0;
    this.pvLoopLength = 0;
    this.pvPartialLength = 0;
    this.instabilityWarning = null;
    this.lastEval = evaluate(this.state, this.params, this.device, this.context());
  }

  /** Advance the model by `seconds` of simulated time. */
  advance(seconds: number): void {
    const steps = Math.min(Math.round(seconds / DT), 20000);
    for (let i = 0; i < steps; i++) this.step();
  }

  /** Advance to a periodic steady state without publishing anything. */
  settle(seconds = 25): void {
    const chunks = Math.ceil(seconds / 1.5);
    for (let i = 0; i < chunks; i++) this.advance(1.5);
  }

  private step(): void {
    const s = this.state;
    const p = this.params;
    const d = this.device;
    const devices = activeDevices(d.kind);

    /* ---- ramps: control signals, integrated separately from the physiology ---- */
    const a = (tau: number) => 1 - Math.exp(-DT / tau);
    s.deviceRamp += ((devices.iabp ? 1 : 0) - s.deviceRamp) * a(TAU_DEVICE);
    s.impellaRamp += ((devices.impella ? 1 : 0) - s.impellaRamp) * a(TAU_IMPELLA);
    s.impellaLevelSmooth +=
      (levelIndex(d.impellaLevel) - s.impellaLevelSmooth) * a(TAU_LEVEL);
    s.ecmoRamp += ((devices.ecmo ? d.ecmoTargetFlow : 0) - s.ecmoRamp) * a(TAU_ECMO);
    s.appliedStressedVolume +=
      (p.stressedVolume - s.appliedStressedVolume) * a(TAU_PRELOAD);

    /* ---- Heun step ---- */
    const ctx = this.context();
    const k1 = evaluate(s, p, d, ctx);

    const cycleTime = 60 / Math.max(p.heartRate, 20);
    const mid: CirculatoryState = {
      ...s,
      vLv: s.vLv + k1.dVlv * DT,
      vAo: s.vAo + k1.dVao * DT,
      vSa: s.vSa + k1.dVsa * DT,
      vVen: s.vVen + k1.dVven * DT,
      vPu: s.vPu + k1.dVpu * DT,
      phase: s.phase + DT / cycleTime,
    };
    const k2 = evaluate(mid, p, d, ctx);

    s.vLv += ((k1.dVlv + k2.dVlv) / 2) * DT;
    s.vAo += ((k1.dVao + k2.dVao) / 2) * DT;
    s.vSa += ((k1.dVsa + k2.dVsa) / 2) * DT;
    s.vVen += ((k1.dVven + k2.dVven) / 2) * DT;
    s.vPu += ((k1.dVpu + k2.dVpu) / 2) * DT;

    /* ---- physiologic floors -------------------------------------------------
     * The only clamps in the model, and each has a physical meaning: a chamber
     * cannot hold a negative volume. They are not stability crutches - if one
     * engages hard, instabilityWarning reports it rather than hiding it.       */
    if (s.vLv < 1) s.vLv = 1;
    if (s.vAo < 1) s.vAo = 1;
    if (s.vSa < 1) s.vSa = 1;
    if (s.vVen < 1) s.vVen = 1;
    if (s.vPu < 1) s.vPu = 1;

    s.vBalloon = k1.vBalloon;
    s.t += DT;
    s.phase += DT / cycleTime;

    /* ---- metrics + PV loop sampling ---- */
    this.acc.sample(k1, s.phase, DT);
    this.pvSampleClock += DT;
    if (this.pvSampleClock >= PV_SAMPLE_DT && this.pvPartialLength < PV_POINTS) {
      this.pvSampleClock = 0;
      const i = this.pvPartialLength * 2;
      this.pvPartial[i] = k1.vLv;
      this.pvPartial[i + 1] = k1.pLv;
      this.pvPartialLength++;
    }

    if (s.phase >= 1) {
      s.phase -= 1;
      s.beat++;
      this.closeBeat();
    }

    this.lastEval = k1;
    this.checkPlausibility(k1);
  }

  private closeBeat(): void {
    const ejectionEnd = this.acc.lastEjectionEndPhase;
    const provisional = this.beatsSinceReset < 3;

    const draft = this.acc.finish(this.params, 1, provisional);
    this.valveHistory.push(draft.strokeVolume > 3 ? 1 : 0);
    if (this.valveHistory.length > VALVE_HISTORY) this.valveHistory.shift();
    const openFraction =
      this.valveHistory.reduce((t, v) => t + v, 0) / this.valveHistory.length;

    this.beatsSinceReset++;
    this.metricsValue = this.acc.finish(this.params, openFraction, provisional);

    if (ejectionEnd > 0.05) {
      // light smoothing so IABP timing does not jitter beat to beat
      this.avClosurePhase = this.avClosurePhase * 0.6 + ejectionEnd * 0.4;
    } else {
      this.avClosurePhase = this.avClosurePhase * 0.8 + DEFAULT_AV_CLOSURE_PHASE * 0.2;
    }

    this.acc.reset();

    const n = Math.min(this.pvPartialLength, PV_POINTS);
    if (n > 8) {
      this.pvLoop.set(this.pvPartial.subarray(0, n * 2));
      this.pvLoopLength = n;
    }
    this.pvPartialLength = 0;
    this.pvSampleClock = 0;
  }

  private checkPlausibility(e: Evaluation): void {
    if (
      !Number.isFinite(e.pLv) ||
      !Number.isFinite(e.pAo) ||
      !Number.isFinite(this.state.vLv)
    ) {
      this.instabilityWarning = 'Non-finite state - integration diverged.';
      return;
    }
    const b = PLAUSIBLE_BOUNDS;
    if (this.state.vLv < b.vLv.min || this.state.vLv > b.vLv.max) {
      this.instabilityWarning = `LV volume ${this.state.vLv.toFixed(0)} mL outside plausible range.`;
    } else if (e.pLv < b.pLv.min || e.pLv > b.pLv.max) {
      this.instabilityWarning = `LV pressure ${e.pLv.toFixed(0)} mmHg outside plausible range.`;
    } else if (e.pAo < b.pAo.min || e.pAo > b.pAo.max) {
      this.instabilityWarning = `Aortic pressure ${e.pAo.toFixed(0)} mmHg outside plausible range.`;
    } else {
      this.instabilityWarning = null;
    }
  }

  readout(): InstantaneousReadout {
    const e = this.lastEval;
    const s = this.state;
    return {
      t: s.t,
      phase: s.phase,
      beat: s.beat,
      pLv: e.pLv,
      pAo: e.pAo,
      pSa: e.pSa,
      pVen: e.pVen,
      pPu: e.pPu,
      vLv: s.vLv,
      activation: e.activation,
      eLv: instantaneousElastance(s.vLv, e.activation, this.params),
      qMitral: e.qMitral,
      qAortic: e.qAortic,
      qConduit: e.qConduit,
      qSvr: e.qSvr,
      qRightHeart: e.qRightHeart,
      qImpella: e.qImpella,
      qEcmo: e.qEcmo,
      qBalloon: e.qBalloon,
      vBalloon: e.vBalloon,
      aorticValveOpen: e.aorticValveOpen,
      mitralValveOpen: e.mitralValveOpen,
      impellaSuction: e.impellaSuction,
      ecmoDrainageLimited: e.ecmoDrainageLimited,
      balloonInflated: e.balloonInflated,
    };
  }

  /** Phase at which the aortic valve closed on the previous beat (IABP timing). */
  get aorticClosurePhase(): number {
    return this.avClosurePhase;
  }
}

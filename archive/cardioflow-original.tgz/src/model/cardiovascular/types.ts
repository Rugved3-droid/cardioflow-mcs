/**
 * CardioFlow MCS — core model type definitions.
 *
 * UNIT CONVENTION (used everywhere in /model; never mix):
 *   pressure     mmHg
 *   volume       mL
 *   flow         mL/s          (display converts to L/min: L/min = mL/s * 0.06)
 *   resistance   mmHg*s/mL
 *   compliance   mL/mmHg
 *   elastance    mmHg/mL
 *   time         s
 */

export type DeviceKind = 'none' | 'iabp' | 'impella' | 'vaEcmo' | 'ecpella';

export type IabpTimingMode =
  | 'optimal'
  | 'earlyInflation'
  | 'lateInflation'
  | 'earlyDeflation'
  | 'lateDeflation';

export type ImpellaLevel = 'P2' | 'P4' | 'P6' | 'P8';

/** Physiologic parameters the learner (or a preset) can change. */
export interface CirculatoryParams {
  /** Heart rate, beats/min. */
  heartRate: number;
  /** LV end-systolic elastance (contractility), mmHg/mL. */
  ees: number;
  /** LV minimum (diastolic) elastance, mmHg/mL. Used by the active-elastance term. */
  eesMin: number;
  /** LV unstressed volume for the ESPVR, mL. */
  v0: number;
  /** EDPVR scale coefficient, mmHg. P_ed = edpvrA*(exp(edpvrB*(V - edpvrV0)) - 1) */
  edpvrA: number;
  /** EDPVR stiffness coefficient, 1/mL. */
  edpvrB: number;
  /** EDPVR volume intercept, mL. */
  edpvrV0: number;
  /** Systemic vascular resistance, mmHg*s/mL. */
  svr: number;
  /** Proximal (ascending aorta + arch) compliance, mL/mmHg. */
  cAo: number;
  /** Systemic arterial (descending aorta + distal arteries) compliance, mL/mmHg. */
  cSa: number;
  /** Aortic conduit resistance between proximal aorta and systemic arteries. */
  rAorticConduit: number;
  /** Aortic valve forward resistance. */
  rAorticValve: number;
  /** Mitral valve forward resistance. */
  rMitralValve: number;
  /** Systemic venous + right atrial compliance, mL/mmHg. */
  cVen: number;
  /** Pulmonary venous + left atrial compliance, mL/mmHg. */
  cPu: number;
  /** Lumped pulmonary vascular resistance (right heart transfer). */
  rPulm: number;
  /** Dimensionless right-heart gain (see MODEL.md "Lumped right heart"). */
  rvGain: number;
  /** Total stressed blood volume, mL. This is the preload control. */
  stressedVolume: number;
}

export interface DeviceParams {
  kind: DeviceKind;
  /** IABP */
  iabpTiming: IabpTimingMode;
  /** IABP balloon stroke volume, mL. */
  iabpBalloonVolume: number;
  /** IABP assist ratio: 1 = 1:1, 2 = 1:2, 3 = 1:3 */
  iabpAssistRatio: 1 | 2 | 3;
  /** Impella performance level. */
  impellaLevel: ImpellaLevel;
  /** VA-ECMO target circuit flow, mL/s. */
  ecmoTargetFlow: number;
}

/** The complete integrable state vector plus the bookkeeping the devices need. */
export interface CirculatoryState {
  /** simulation clock, s */
  t: number;
  /** phase within the current cardiac cycle, 0..1 */
  phase: number;
  /** beat counter since reset */
  beat: number;

  /* --- compartment volumes (mL) --- */
  vLv: number;
  vAo: number;
  vSa: number;
  vVen: number;
  vPu: number;

  /* --- device internal state --- */
  /** current IABP balloon volume, mL */
  vBalloon: number;
  /** device ramp 0..1 — smooths device switch-on/off over ~1.5 s */
  deviceRamp: number;
  /** on/off speed ramp for the axial pump, 0..1 */
  impellaRamp: number;
  /** fractional performance-level index, ramps between P2..P8 */
  impellaLevelSmooth: number;
  /** ramping value of ecmo flow, mL/s */
  ecmoRamp: number;
  /** applied stressed volume, ramps toward params.stressedVolume */
  appliedStressedVolume: number;
}

/** Everything computed from the state at one instant. Purely derived — never integrated. */
export interface InstantaneousReadout {
  t: number;
  phase: number;
  beat: number;

  pLv: number;
  pAo: number;
  pSa: number;
  pVen: number;
  pPu: number;
  vLv: number;

  /** normalized LV activation 0..1 */
  activation: number;
  /** instantaneous LV elastance, mmHg/mL */
  eLv: number;

  qMitral: number;
  qAortic: number;
  qConduit: number;
  qSvr: number;
  qRightHeart: number;

  qImpella: number;
  qEcmo: number;
  /** balloon dV/dt, mL/s — positive = inflating (displacing blood) */
  qBalloon: number;
  vBalloon: number;

  aorticValveOpen: boolean;
  mitralValveOpen: boolean;
  impellaSuction: boolean;
  ecmoDrainageLimited: boolean;
  balloonInflated: boolean;
}

export type AorticValveStatus =
  | 'opening-normally'
  | 'intermittent'
  | 'minimal'
  | 'not-opening';

/** Beat-averaged hemodynamics. Recomputed at each beat boundary. */
export interface BeatMetrics {
  heartRate: number;
  /** systolic arterial pressure (proximal aorta), mmHg */
  sbp: number;
  dbp: number;
  map: number;
  pulsePressure: number;
  /** peak diastolic pressure during IABP inflation, mmHg (== dbp when no balloon) */
  augmentedDiastolicPressure: number;
  /** aortic end-diastolic pressure immediately before ejection */
  assistedEndDiastolicPressure: number;

  lvedp: number;
  lvedv: number;
  lvesv: number;
  lvSystolicPressure: number;
  strokeVolume: number;
  ejectionFraction: number;

  /** native LV forward output across the aortic valve, L/min */
  nativeCardiacOutput: number;
  /** total device flow (Impella + ECMO), L/min */
  deviceFlow: number;
  /** flow actually delivered to the systemic arteries, L/min */
  totalSystemicFlow: number;

  /** LV stroke work from the PV loop area, mmHg*mL (≈ 1.333e-4 J per unit) */
  strokeWork: number;
  /** cardiac power output from total systemic flow, W */
  cardiacPowerOutput: number;

  /** left atrial / PCWP surrogate, mean mmHg */
  meanLaPressure: number;
  meanVenousPressure: number;

  /** Buckberg-style diastolic pressure-time index, mmHg*s */
  dpti: number;
  /** systolic pressure-time index, mmHg*s */
  spti: number;
  /** endocardial viability ratio = DPTI/SPTI */
  evr: number;

  aorticValveStatus: AorticValveStatus;
  /** fraction of the last beats in which the aortic valve opened, 0..1 */
  valveOpenFraction: number;
  /** fraction of the cardiac cycle spent ejecting */
  ejectionTimeFraction: number;

  /** pulsatility of the arterial waveform (PP/MAP) */
  pulsatilityIndex: number;

  /** true when the model is still filling its first beats and metrics are provisional */
  provisional: boolean;
}

export interface ModelConfiguration {
  params: CirculatoryParams;
  device: DeviceParams;
}

/** A snapshot published to the UI. */
export interface SimulationSnapshot {
  readout: InstantaneousReadout;
  metrics: BeatMetrics;
  config: ModelConfiguration;
  /** the most recently completed PV loop, resampled */
  pvLoop: Float32Array;
  /** true while a beat is in progress and the partial loop is being traced */
  pvLoopPartial: Float32Array;
  pvLoopPartialLength: number;
}

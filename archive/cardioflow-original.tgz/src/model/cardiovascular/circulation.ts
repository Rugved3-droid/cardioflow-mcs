/**
 * Closed-loop lumped-parameter circulation.
 *
 * Compartments (all volumes in mL):
 *
 *        [PU] pulmonary veins + LA  --mitral-->  [LV]  --aortic valve-->  [AO] asc. aorta + arch
 *          ^                                       |                        |
 *          |                                  (axial pump)            (aortic conduit)
 *     lumped right heart                           |                        v
 *          |                                       +----------------->   [SA] desc. aorta + systemic arteries
 *          |                                                                |   ^          ^
 *        [VEN] systemic veins + RA  <-------- systemic runoff (SVR) --------+   |      (IABP balloon
 *          |                                                                    |       displacement)
 *          +--------------------- ECMO drainage ------> circuit --> ECMO return +
 *
 * Only the LV carries a true anatomic volume (it must, for the PV loop). AO, SA,
 * VEN and PU carry *stressed* volume: P = V / C, with unstressed volume implicit.
 * Total tracked volume is conserved by construction and additionally held to the
 * preload setpoint by a slow corrector (see `cardiovascularModel.ts`).
 */

import type { CirculatoryParams, CirculatoryState, DeviceParams } from './types';
import { activationAt, lvPressure } from './elastance';
import { conduitFlow, forwardValve } from './valves';
import { balloonState, DEFAULT_AV_CLOSURE_PHASE } from '../devices/iabp';
import { impellaFlowAtIndex } from '../devices/impella';
import { ecmoFlow } from '../devices/vaEcmo';
import { activeDevices } from '../devices/ecpella';

export interface Derivatives {
  dVlv: number;
  dVao: number;
  dVsa: number;
  dVven: number;
  dVpu: number;
}

export interface EvaluationContext {
  /** phase of aortic valve closure observed on the previous beat, 0..1 */
  avClosurePhase: number;
  /** total volume setpoint the corrector drives toward, mL */
  volumeSetpoint: number;
}

export interface Evaluation extends Derivatives {
  pLv: number;
  pAo: number;
  pSa: number;
  pVen: number;
  pPu: number;
  activation: number;
  qMitral: number;
  qAortic: number;
  qConduit: number;
  qSvr: number;
  qRightHeart: number;
  qImpella: number;
  qEcmo: number;
  qBalloon: number;
  vBalloon: number;
  aorticValveOpen: boolean;
  mitralValveOpen: boolean;
  impellaSuction: boolean;
  ecmoDrainageLimited: boolean;
  balloonInflated: boolean;
}

/** Time constant of the circulating-volume corrector, s. */
const VOLUME_TAU = 0.6;

/**
 * Lumped right heart + pulmonary circulation.
 *
 * The RV is not modelled as an elastance chamber. Instead the right heart is a
 * gain element that converts its filling pressure into a pulmonary driving
 * pressure, and flow crosses the lung against pulmonary venous back-pressure:
 *
 *     Q_rh = max( (rvGain * P_ven - P_pu) / R_pulm , 0 )
 *
 * This is deliberately the crudest defensible element in the model. It gives the
 * three behaviours the LV-focused teaching needs — Frank-Starling sensitivity to
 * venous return, self-limitation as pulmonary venous pressure rises, and a fall in
 * LV preload when ECMO drains the venous reservoir — without pretending to model
 * RV failure. Replacing it with a true RV elastance chamber is the single change
 * that would unlock the RV/RVAD extensions. See docs/MODEL.md.
 */
export function rightHeartFlow(
  pVen: number,
  pPu: number,
  p: CirculatoryParams,
): number {
  const driving = p.rvGain * pVen - pPu;
  return driving > 0 ? driving / p.rPulm : 0;
}

export function evaluate(
  s: CirculatoryState,
  p: CirculatoryParams,
  d: DeviceParams,
  ctx: EvaluationContext,
): Evaluation {
  const cycleTime = 60 / Math.max(p.heartRate, 20);
  const devices = activeDevices(d.kind);

  const activation = activationAt(s.phase, p.heartRate);
  const pLv = lvPressure(s.vLv, activation, p);
  const pAo = s.vAo / p.cAo;
  const pSa = s.vSa / p.cSa;
  const pVen = s.vVen / p.cVen;
  const pPu = s.vPu / p.cPu;

  /* ---- valves and conduits ---- */
  const mitral = forwardValve(pPu, pLv, p.rMitralValve);
  const aortic = forwardValve(pLv, pAo, p.rAorticValve);
  const qConduit = conduitFlow(pAo, pSa, p.rAorticConduit);
  const qSvr = conduitFlow(pSa, pVen, p.svr);
  const qRightHeart = rightHeartFlow(pVen, pPu, p);

  /* ---- devices ---- */
  let qImpella = 0;
  let impellaSuction = false;
  if (devices.impella && s.impellaRamp > 0) {
    const out = impellaFlowAtIndex(s.impellaLevelSmooth, pAo, pLv, s.vLv, s.impellaRamp);
    qImpella = out.q;
    impellaSuction = out.suction;
  }

  let qEcmo = 0;
  let ecmoDrainageLimited = false;
  if (devices.ecmo && s.ecmoRamp > 0) {
    const out = ecmoFlow(s.ecmoRamp, s.vVen);
    qEcmo = out.q;
    ecmoDrainageLimited = out.drainageLimited;
  }

  let qBalloon = 0;
  let vBalloon = 0;
  let balloonInflated = false;
  if (devices.iabp && s.deviceRamp > 0) {
    const avClose = ctx.avClosurePhase > 0 ? ctx.avClosurePhase : DEFAULT_AV_CLOSURE_PHASE;
    const b = balloonState(
      s.phase,
      cycleTime,
      s.beat,
      d.iabpBalloonVolume,
      d.iabpTiming,
      avClose,
      d.iabpAssistRatio,
      s.deviceRamp,
    );
    qBalloon = b.dVdt;
    vBalloon = b.volume;
    balloonInflated = b.inflated;
  }

  /* ---- circulating-volume corrector -----------------------------------------
   * Drives total tracked volume toward the preload setpoint (less whatever the
   * balloon is currently displacing) with a 0.6 s time constant. This does two
   * jobs at once: it makes the preload slider act like a smooth volume infusion
   * rather than a step, and it absorbs any integration drift so the model cannot
   * slowly gain or lose blood over a long session.                            */
  const totalVolume = s.vLv + s.vAo + s.vSa + s.vVen + s.vPu;
  const qVolumeCorrection =
    (ctx.volumeSetpoint - vBalloon - totalVolume) / VOLUME_TAU;

  /* ---- conservation ---- */
  const dVlv = mitral.q - aortic.q - qImpella;
  const dVao = aortic.q + qImpella - qConduit;
  const dVsa = qConduit - qSvr + qEcmo - qBalloon;
  const dVven = qSvr - qRightHeart - qEcmo + qVolumeCorrection;
  const dVpu = qRightHeart - mitral.q;

  return {
    dVlv,
    dVao,
    dVsa,
    dVven,
    dVpu,
    pLv,
    pAo,
    pSa,
    pVen,
    pPu,
    activation,
    qMitral: mitral.q,
    qAortic: aortic.q,
    qConduit,
    qSvr,
    qRightHeart,
    qImpella,
    qEcmo,
    qBalloon,
    vBalloon,
    aorticValveOpen: aortic.open && aortic.q > 1,
    mitralValveOpen: mitral.open,
    impellaSuction,
    ecmoDrainageLimited,
    balloonInflated,
  };
}

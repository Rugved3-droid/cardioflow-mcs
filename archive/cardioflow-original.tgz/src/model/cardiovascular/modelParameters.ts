/**
 * Central parameter configuration.
 *
 * Every number the model uses lives here or in the device curve tables. Nothing
 * physiological should be written inline in a component.
 */

import type { CirculatoryParams, DeviceParams } from './types';

/** Integration timestep, s. Heun (RK2) is used, so this is comfortably inside
 *  the stiffest time constant in the model (R_aorticValve * C_ao ~ 3.6 ms). */
export const DT = 1e-4;

/** Simulation seconds advanced per real second at 1x speed. */
export const REALTIME_RATE = 1.0;

export const BASELINE_PARAMS: CirculatoryParams = {
  heartRate: 75,
  ees: 2.4,
  eesMin: 0.06,
  v0: 10,
  edpvrA: 0.42,
  edpvrB: 0.0255,
  edpvrV0: 22,
  svr: 1.05,
  cAo: 0.62,
  cSa: 1.45,
  rAorticConduit: 0.022,
  rAorticValve: 0.0055,
  rMitralValve: 0.0045,
  cVen: 62,
  cPu: 11,
  rPulm: 0.052,
  rvGain: 1.62,
  stressedVolume: 900,
};

export const DEFAULT_DEVICE: DeviceParams = {
  kind: 'none',
  iabpTiming: 'optimal',
  iabpBalloonVolume: 40,
  iabpAssistRatio: 1,
  impellaLevel: 'P4',
  ecmoTargetFlow: 3.5 / 0.06,
};

/** Bounds used by the sliders and by the development plausibility warnings. */
export const PARAM_BOUNDS = {
  heartRate: { min: 40, max: 160, step: 1 },
  ees: { min: 0.2, max: 4.5, step: 0.05 },
  svr: { min: 0.4, max: 2.6, step: 0.02 },
  stressedVolume: { min: 620, max: 1250, step: 5 },
  cSa: { min: 0.5, max: 3.0, step: 0.05 },
} as const;

/** Development-mode plausibility envelope. Leaving it raises a console warning
 *  but never alters the state — we want to see instability, not hide it. */
export const PLAUSIBLE_BOUNDS = {
  vLv: { min: -5, max: 500 },
  pLv: { min: -20, max: 350 },
  pAo: { min: -10, max: 320 },
  pVen: { min: -10, max: 60 },
  pPu: { min: -10, max: 70 },
} as const;

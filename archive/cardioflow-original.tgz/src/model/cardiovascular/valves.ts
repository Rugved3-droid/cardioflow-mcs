/**
 * Valve elements.
 *
 * A valve is a pressure-driven diode. A hard `max(dP,0)/R` diode is stable here
 * because the integration step is far smaller than R*C for every compartment, but
 * we additionally give the closed valve a very large finite resistance rather than
 * zero flow. That keeps the flow function continuous (no derivative discontinuity
 * at dP = 0), which removes the numerical chatter that otherwise appears when the
 * aortic valve sits exactly at its opening threshold — precisely the state VA-ECMO
 * drives the ventricle into, and the one we most need to render cleanly.
 */

/** Resistance of a closed valve. Large, but finite for continuity. */
export const R_CLOSED = 2000; // mmHg*s/mL

export interface ValveFlow {
  q: number;
  open: boolean;
}

export function forwardValve(
  pUpstream: number,
  pDownstream: number,
  rOpen: number,
): ValveFlow {
  const dp = pUpstream - pDownstream;
  if (dp > 0) return { q: dp / rOpen, open: true };
  // trivial regurgitant leak, keeps the function continuous through dp = 0
  return { q: dp / R_CLOSED, open: false };
}

/** A plain bidirectional conduit (no valve). */
export function conduitFlow(pUpstream: number, pDownstream: number, r: number): number {
  return (pUpstream - pDownstream) / r;
}

/**
 * Time-varying elastance for the left ventricle.
 *
 * We use the normalized "double-Hill" activation function of Stergiopulos/Mynard,
 * which produces a smooth, C1-continuous activation curve with a realistic
 * asymmetric rise and fall. The curve is normalized to peak at 1.0.
 *
 * The LV pressure is then blended between the ESPVR and the EDPVR by activation
 * (Mynard 2012 form), which keeps LVEDP on a physiologic exponential EDPVR while
 * peak systolic pressure follows the linear ESPVR. This matters for teaching:
 * ventricular distension has to produce a steeply rising filling pressure.
 */

import type { CirculatoryParams } from './types';

/** Shape constants for the double-Hill activation. Dimensionless fractions of cycle. */
const ALPHA1 = 0.303; // rise midpoint, fraction of cycle
const ALPHA2 = 0.508; // fall midpoint, fraction of cycle
const N1 = 1.32;
const N2 = 21.9;

/**
 * Systole shortens as heart rate rises. Bazett-like scaling of the activation
 * timing so tachycardia does not simply compress diastole out of existence.
 * Returns a multiplier applied to the phase before evaluating the Hill terms.
 */
export function systolicTimeScale(heartRate: number): number {
  const cycle = 60 / Math.max(heartRate, 1);
  // reference cycle 0.8 s (75 bpm); systole scales with sqrt(cycle)
  const ref = 0.8;
  const scale = Math.sqrt(ref / cycle);
  return clamp(scale, 0.6, 1.9);
}

/** Raw (unnormalized) double-Hill value at a phase in [0,1). */
function doubleHill(phase: number, scale: number): number {
  const p = phase * scale;
  const g1 = Math.pow(p / ALPHA1, N1);
  const g2 = Math.pow(p / ALPHA2, N2);
  return (g1 / (1 + g1)) * (1 / (1 + g2));
}

// Peak of the raw curve, precomputed per scale factor and memoized — the curve is
// evaluated once per integration substep so this must stay cheap.
const peakCache = new Map<number, number>();
function doubleHillPeak(scale: number): number {
  const key = Math.round(scale * 1000);
  const cached = peakCache.get(key);
  if (cached !== undefined) return cached;
  let peak = 1e-9;
  for (let i = 0; i <= 2000; i++) {
    const v = doubleHill(i / 2000, scale);
    if (v > peak) peak = v;
  }
  peakCache.set(key, peak);
  return peak;
}

/** Normalized LV activation, 0..1, peaking at 1.0 in mid-systole. */
export function activationAt(phase: number, heartRate: number): number {
  const scale = systolicTimeScale(heartRate);
  const raw = doubleHill(wrapPhase(phase), scale);
  return clamp(raw / doubleHillPeak(scale), 0, 1);
}

/** End-diastolic pressure-volume relationship (passive stiffness), mmHg. */
export function edpvr(volume: number, p: CirculatoryParams): number {
  const dv = volume - p.edpvrV0;
  if (dv <= 0) {
    // Below the volume intercept the ventricle is on its flat, slightly negative limb.
    return p.edpvrA * p.edpvrB * dv;
  }
  // Guard the exponent so a runaway volume cannot produce Infinity.
  const x = Math.min(p.edpvrB * dv, 8);
  return p.edpvrA * (Math.exp(x) - 1);
}

/** End-systolic pressure-volume relationship (active, linear), mmHg. */
export function espvr(volume: number, p: CirculatoryParams): number {
  return p.ees * (volume - p.v0);
}

/**
 * Instantaneous LV pressure.
 * P(V,t) = a(t) * Ees*(V - V0)  +  (1 - a(t)) * P_ed(V)
 */
export function lvPressure(
  volume: number,
  activation: number,
  p: CirculatoryParams,
): number {
  const active = espvr(volume, p);
  const passive = edpvr(volume, p);
  return activation * active + (1 - activation) * passive;
}

/** Instantaneous elastance, reported for display only (dP/dV is not used to integrate). */
export function instantaneousElastance(
  volume: number,
  activation: number,
  p: CirculatoryParams,
): number {
  const h = 0.5;
  return (
    (lvPressure(volume + h, activation, p) - lvPressure(volume - h, activation, p)) /
    (2 * h)
  );
}

export function wrapPhase(phase: number): number {
  const w = phase % 1;
  return w < 0 ? w + 1 : w;
}

export function clamp(x: number, lo: number, hi: number): number {
  return x < lo ? lo : x > hi ? hi : x;
}

/**
 * Per-beat metric accumulation.
 *
 * Every displayed hemodynamic number is integrated here from the same state the
 * anatomy, the waveforms and the PV loop are drawn from. Nothing in the UI
 * computes physiology of its own.
 */

import type { AorticValveStatus, BeatMetrics, CirculatoryParams } from './types';
import type { Evaluation } from './circulation';

const ML_S_TO_L_MIN = 0.06;

export class BeatAccumulator {
  private duration = 0;

  private pAoSum = 0;
  private pAoMax = -1e9;
  private pAoMin = 1e9;
  private pAoDiastolicMax = -1e9;
  private pAoAtEjectionOnset: number | null = null;
  private pAoLateDiastolicMin = 1e9;

  private pLvMax = -1e9;
  private vLvMax = -1e9;
  private vLvMin = 1e9;
  private pLvAtEdv = 0;

  private pPuSum = 0;
  private pVenSum = 0;

  private aorticVolume = 0;
  private impellaVolume = 0;
  private ecmoVolume = 0;
  private systemicVolume = 0;

  private strokeWork = 0;
  private dpti = 0;
  private spti = 0;
  private ejectionTime = 0;

  private ejectionEndPhase = 0;
  private sawEjection = false;

  reset(): void {
    this.duration = 0;
    this.pAoSum = 0;
    this.pAoMax = -1e9;
    this.pAoMin = 1e9;
    this.pAoDiastolicMax = -1e9;
    this.pAoAtEjectionOnset = null;
    this.pAoLateDiastolicMin = 1e9;
    this.pLvMax = -1e9;
    this.vLvMax = -1e9;
    this.vLvMin = 1e9;
    this.pLvAtEdv = 0;
    this.pPuSum = 0;
    this.pVenSum = 0;
    this.aorticVolume = 0;
    this.impellaVolume = 0;
    this.ecmoVolume = 0;
    this.systemicVolume = 0;
    this.strokeWork = 0;
    this.dpti = 0;
    this.spti = 0;
    this.ejectionTime = 0;
    this.ejectionEndPhase = 0;
    this.sawEjection = false;
  }

  /** Called once per integration substep with the evaluation at that instant. */
  sample(e: Evaluation, phase: number, dt: number): void {
    this.duration += dt;

    this.pAoSum += e.pAo * dt;
    if (e.pAo > this.pAoMax) this.pAoMax = e.pAo;
    if (e.pAo < this.pAoMin) this.pAoMin = e.pAo;

    if (e.pLv > this.pLvMax) this.pLvMax = e.pLv;
    if (e.vLv > this.vLvMax) {
      this.vLvMax = e.vLv;
      this.pLvAtEdv = e.pLv;
    }
    if (e.vLv < this.vLvMin) this.vLvMin = e.vLv;

    this.pPuSum += e.pPu * dt;
    this.pVenSum += e.pVen * dt;

    this.aorticVolume += e.qAortic * dt;
    this.impellaVolume += e.qImpella * dt;
    this.ecmoVolume += e.qEcmo * dt;
    this.systemicVolume += e.qSvr * dt;

    // Stroke work = area enclosed by the PV loop = -(integral of P dV).
    this.strokeWork -= e.pLv * e.dVlv * dt;

    const ejecting = e.qAortic > 1;
    if (ejecting) {
      this.ejectionTime += dt;
      this.ejectionEndPhase = phase;
      if (!this.sawEjection) {
        this.sawEjection = true;
        this.pAoAtEjectionOnset = e.pAo;
      }
    }

    // Systole defined by activation, so it remains well defined even when the
    // aortic valve never opens (the state VA-ECMO can drive the LV into).
    const inSystole = e.activation > 0.05;
    if (inSystole) {
      this.spti += e.pLv * dt;
    } else {
      const gradient = e.pAo - e.pLv;
      if (gradient > 0) this.dpti += gradient * dt;
      if (e.pAo > this.pAoDiastolicMax) this.pAoDiastolicMax = e.pAo;
    }

    // Late-diastolic aortic pressure: the pressure the LV must overcome to open
    // the valve. With a correctly timed IABP this is the *assisted* end-diastolic
    // pressure, and it should fall.
    if (phase > 0.86) {
      if (e.pAo < this.pAoLateDiastolicMin) this.pAoLateDiastolicMin = e.pAo;
    }
  }

  get lastEjectionEndPhase(): number {
    return this.sawEjection ? this.ejectionEndPhase : 0;
  }

  finish(
    p: CirculatoryParams,
    valveOpenFraction: number,
    provisional: boolean,
  ): BeatMetrics {
    const d = Math.max(this.duration, 1e-6);
    const map = this.pAoSum / d;
    const sbp = this.pAoMax;
    const dbp = this.pAoMin;

    const strokeVolume = this.aorticVolume;
    const lvedv = this.vLvMax;
    const lvesv = this.vLvMin;

    const nativeCardiacOutput = (strokeVolume / d) * ML_S_TO_L_MIN * 60;
    const deviceFlow = ((this.impellaVolume + this.ecmoVolume) / d) * ML_S_TO_L_MIN * 60;
    const totalSystemicFlow = (this.systemicVolume / d) * ML_S_TO_L_MIN * 60;

    const status = classifyAorticValve(strokeVolume, valveOpenFraction);

    const spti = Math.max(this.spti, 1e-6);

    return {
      heartRate: 60 / d,
      sbp,
      dbp,
      map,
      pulsePressure: sbp - dbp,
      augmentedDiastolicPressure:
        this.pAoDiastolicMax > -1e8 ? this.pAoDiastolicMax : dbp,
      assistedEndDiastolicPressure:
        this.pAoAtEjectionOnset ??
        (this.pAoLateDiastolicMin < 1e8 ? this.pAoLateDiastolicMin : dbp),
      lvedp: this.pLvAtEdv,
      lvedv,
      lvesv,
      lvSystolicPressure: this.pLvMax,
      strokeVolume,
      ejectionFraction: lvedv > 1 ? (strokeVolume / lvedv) * 100 : 0,
      nativeCardiacOutput,
      deviceFlow,
      totalSystemicFlow,
      strokeWork: Math.max(this.strokeWork, 0),
      cardiacPowerOutput: (map * totalSystemicFlow) / 451,
      meanLaPressure: this.pPuSum / d,
      meanVenousPressure: this.pVenSum / d,
      dpti: this.dpti,
      spti,
      evr: this.dpti / spti,
      aorticValveStatus: status,
      valveOpenFraction,
      ejectionTimeFraction: this.ejectionTime / d,
      pulsatilityIndex: map > 1 ? (sbp - dbp) / map : 0,
      provisional,
    };
  }
}

export function classifyAorticValve(
  strokeVolume: number,
  openFraction: number,
): AorticValveStatus {
  if (strokeVolume < 1.0 || openFraction <= 0.01) return 'not-opening';
  if (openFraction < 0.9) return 'intermittent';
  if (strokeVolume < 15) return 'minimal';
  return 'opening-normally';
}

export const AORTIC_VALVE_LABEL: Record<AorticValveStatus, string> = {
  'opening-normally': 'Opening normally',
  intermittent: 'Intermittent opening',
  minimal: 'Minimal opening',
  'not-opening': 'Not opening',
};

export function emptyMetrics(): BeatMetrics {
  return {
    heartRate: 0,
    sbp: 0,
    dbp: 0,
    map: 0,
    pulsePressure: 0,
    augmentedDiastolicPressure: 0,
    assistedEndDiastolicPressure: 0,
    lvedp: 0,
    lvedv: 0,
    lvesv: 0,
    lvSystolicPressure: 0,
    strokeVolume: 0,
    ejectionFraction: 0,
    nativeCardiacOutput: 0,
    deviceFlow: 0,
    totalSystemicFlow: 0,
    strokeWork: 0,
    cardiacPowerOutput: 0,
    meanLaPressure: 0,
    meanVenousPressure: 0,
    dpti: 0,
    spti: 1,
    evr: 0,
    aorticValveStatus: 'opening-normally',
    valveOpenFraction: 1,
    ejectionTimeFraction: 0,
    pulsatilityIndex: 0,
    provisional: true,
  };
}
